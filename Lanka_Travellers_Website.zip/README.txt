LANKA TRAVELLERS – ASSIGNMENT WEBSITE
========================================

Files:
- index.html        Home Page
- packages.html     Travel Packages Page (4 packages)
- about.html        About Us Page
- contact.html      Contact Us Page + demo form + Google Map
- style.css         Responsive design
- script.js         Mobile menu + demo contact form

IMPORTANT:
The phone, email and address are fictional/sample details for the academic project.
Replace them with your lecturer-approved details if required.

HOW TO PUBLISH FREE:
Option 1 – GitHub Pages:
1. Create a free GitHub account.
2. Create a new public repository, e.g. lanka-travellers.
3. Upload all files in this folder to the repository root.
4. Open Settings > Pages.
5. Select Deploy from branch > main > /(root) > Save.
6. GitHub will provide a free URL such as:
   https://YOUR-USERNAME.github.io/lanka-travellers/

Option 2 – WordPress:
Recreate the four pages in a free WordPress.com site and use the text/images from these files.

SUBMISSION:
1. Live Website URL
2. Screenshots of Home, Packages, About and Contact pages.
